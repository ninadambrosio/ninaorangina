//Press a button to choose your path
//See the README file for more information

/* VARIABLES */
let enterButton;
let a1Button;
let a2Button;
let b1Button;
let b2Button;
let screen = 0;

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(600, 400);
  textAlign(CENTER);
  textSize(20);
  noStroke();

  // Set up the home screen
  background("pink");
  text(
    "Once upon a time there was a princess named Lisa. \nShe had recently come of age\n where she could now choose a castle.\n Do you want to enter the castle matchmaker?",
    width / 2,
    height / 2 - 100
  );

  // Create buttons for all screens
  enterButton = new Sprite(width/2, height/2 + 100);
  a1Button = new Sprite(-200,-200);
  a2Button = new Sprite(-50,-50);
  b1Button = new Sprite(-100,-100);
  b2Button = new Sprite(-150,-150)
}

/* DRAW LOOP REPEATS */
function draw() {
  // Display enter button
enterButton.w = 100;
enterButton.h = 50;
enterButton.collider = 'k';
enterButton.color = 'plum';
enterButton.text = 'enter'


  // Check enter button
if (enterButton.mouse.presses()) {
  print("pressed");
  showScreen1();
  screen = 1;
}
  if (screen == 1){
    if (a1Button.mouse.presses()) {
  showScreen2();
    screen = 2;
    } else if (a2Button.mouse.presses()) {
      showScreen5();
      screen = 5;
    }
  }
    else if (screen==2) {
      if (b1Button.mouse.presses()) {
        showScreen3();
        screen = 3;
      } else if (b2Button.mouse.presses()) {
        showScreen4();
        screen = 4;
      }
    }
  
  
  print (screen);
}

/* FUNCTIONS TO DISPLAY SCREENS */
function showScreen1(){
  background("paleturquoise");
  text("Lisa could pick thru thousands of castles\n but wasn't sure which to pick. She didn't know if she even\n wanted to put in effort into finding one.",width/2,height/2-100);
  enterButton.pos = {x:-100,y:-100};

    // Add A1 button
  a1Button.pos = {x:width/2-120,y:height/2+100};
  a1Button.h = 50;
  a1Button.w = width/3;
  a1Button.collider = 'k';
  a1Button.color = 'plum';
  a1Button.text = 'Try to find a castle';
    // Add A2 button
  a2Button.pos = {x:width/2+120,y:height/2+100};
  a2Button.h = 50;
  a2Button.w = width/3;
  a2Button.collider = 'k';
  a2Button.color = 'plum';
  a2Button.text = 'Give up & stay home';
}
function showScreen2(){
  print('display screen 2');
    background("palegreen");
    text("Lisa decided to try but still wasn't sure where to go.\n The South Castle was nearby and familar to her,\nbut The North Castle was new, shiny, and full of friends\n The only thing stopping her from going north was the\nlong journey full of terrible weather.\n Should she brave the storm?"
        ,width/2,height/2-100);
      a1Button.pos = {x:-200,y:-200};
      a2Button.pos = {x:-50,y:-50};
  //add b1
      b1Button.pos = {x:width/2-120,y:height/2+100};
      b1Button.h = 50;
      b1Button.w = width/3;
      b1Button.collider = 'k';
      b1Button.color = 'plum';
      b1Button.text = 'Brave the storm';
  //add b2
      b2Button.pos = {x:width/2+120,y:height/2+100};
      b2Button.h = 50;
      b2Button.w = width/3;
      b2Button.collider = 'k';
      b2Button.color = 'plum';
      b2Button.text = 'Pick The South Castle';    
}
function showScreen3(){
  print("Display screen 3");
  background("lavender");
  text("yayy she made it! so happy",width/2,height/2-100);
  b1Button.pos = {x:-200,y:-200};
  b2Button.pos = {x:-50,y:-50};
}
function showScreen4(){
  print("Display screen 4");
  background("plum");
  text("far from friends but close to home.",width/2,height/2-100);
  b1Button.pos = {x:-200,y:-200};
  b2Button.pos = {x:-50,y:-50};
}
function showScreen5(){
  print("Display screen 5");
  background("lightgreen");
  text("She stayed home.",width/2,height/2-100);
  a1Button.pos = {x:-200,y:-200};
  a2Button.pos = {x:-50,y:-50};
}
