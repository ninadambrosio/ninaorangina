/* VARIABLES */
let eyeWidth = 30;
let eyeHeight = 30;
let pupilWidth = 10;
let pupilHeight = 10;
/* SETUP RUNS ONCE */
function setup() {
  //sets the screen size
  createCanvas(400,400); 

  //sets the background color
  background("grey"); 
}

/* DRAW LOOP REPEATS */
function draw() {
  angleMode(DEGREES);
  //Face
  fill("#f5d3bf");
  strokeWeight(.5);
  ellipse(width/2,height/2,130,150);
  //Eyes
  if (mouseIsPressed) {
    //Eyes closed
    fill(0);
    ellipse(170,180,eyeWidth,eyeHeight/8);
    ellipse(220,180,eyeWidth,eyeHeight/8);
  }
  else {
  fill("#ede8e7");
  ellipse(170,180,eyeWidth,eyeHeight);
  ellipse(220,180,eyeWidth,eyeHeight);
  }
 
  //Pupils
  if (mouseIsPressed){
    fill(0);
    ellipse(170,180,pupilWidth,pupilHeight/8);
    ellipse(220,180,pupilWidth,pupilHeight/8);
  }
  else {
  fill("#e0d245");
  ellipse(170,180,pupilWidth,pupilHeight);
  ellipse(220,180,pupilWidth,pupilHeight);
  }
  //Mouth
  fill("pink");
  arc(200,230,50,50,0,180);
  line(180,230,220,230);
  //Teeth
  fill("white");
  triangle(180,230,185,240,190,230);
  triangle(200,230,205,240,210,230);
  //Horns
  fill("red");
  triangle(150,150,160,70,170,150);
  triangle(210,150,220,70,230,150);
  //Hair
  strokeWeight(0);
  fill("#deb28e");
  arc(200,160,140,100,180,0);
  triangle(190,150,195,190,200,150);
  rect(130,150,30,200);
  rect(240,150,30,200);
  
  //Text
  fill("black");
  textSize(15);
  text('power from chainsaw man my bae :3',20,20);
}